package com.example.kuwait;

public class Car {



private int bost ;

private String color;

private String name ;

private  int number  ;


    public int getBost() {
        return bost;
    }

    public void setBost(int bost) {
        this.bost = bost;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
